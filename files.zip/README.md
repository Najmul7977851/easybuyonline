# EasyBuyOnline

Demo e-commerce storefront: catalog, search and filters, cart, 5-step checkout,
customer login and registration (OTP), customer dashboard, and an admin panel.

## Live site
After enabling GitHub Pages (below), the site is at:
`https://YOUR-USERNAME.github.io/easybuyonline/`

## Publish to GitHub Pages
1. Create a new public repository named `easybuyonline` on GitHub.
2. Upload these files (or push with git):
   ```bash
   git init && git add . && git commit -m "Initial EasyBuyOnline demo"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/easybuyonline.git
   git push -u origin main
   ```
3. In the repository, go to **Settings → Pages → Build and deployment → Source**, and choose **GitHub Actions**.
4. Each push to `main` deploys automatically through `.github/workflows/pages.yml`.
5. Replace `YOUR-USERNAME` in `robots.txt` and `sitemap.xml`.

## Demo credentials
- Customer OTP: `1234`
- Admin password: `admin123`

## Limitations
This is a front-end demo. Data stays in the visitor's browser. Passwords are not
verified on a server, and payments are simulated. Do not use it to take real
orders or payments until a backend with hashed passwords, a database, and
server-side Razorpay verification is in place. Keep secret keys out of this repository.
